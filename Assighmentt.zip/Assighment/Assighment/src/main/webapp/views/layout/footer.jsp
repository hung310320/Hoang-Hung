<%@ page contentType="text/html; charset=UTF-8" %>

<style>
    .footer {
        background: rgba(0,0,0,0.6);
        backdrop-filter: blur(10px);
        padding: 25px 0;
        margin-top: 50px;
        box-shadow: 0 -5px 20px rgba(0,255,255,0.15);
    }

    .footer p {
        margin: 0;
        color: #aaa;
        font-size: 14px;
    }

    .footer span {
        color: #00e5ff;
        font-weight: bold;
    }
</style>

<footer class="footer text-center">
    <div class="container">
        <p>
            © 2026 <span>Video Sharing System</span> |
            FPT Polytechnic – Lập trình web nâng cao (Java)
        </p>
    </div>
</footer>
