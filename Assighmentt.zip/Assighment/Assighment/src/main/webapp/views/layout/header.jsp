<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="poly.entity.User" %>

<!-- Bootstrap & FontAwesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<%
    // ===============================
    // LẤY USER TỪ SESSION
    // ===============================
    // Nếu chưa đăng nhập → user = null
    User user = (User) session.getAttribute("user");
%>

<style>
    /* ===============================
       STYLE HEADER
       =============================== */
    .navbar {
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(10px);
        box-shadow: 0 0 20px rgba(0,255,255,0.2);
    }

    .navbar-brand {
        font-weight: bold;
        color: #00e5ff !important;
    }

    .nav-link {
        color: #ddd !important;
        margin-right: 15px;
        transition: 0.3s;
    }

    .nav-link:hover {
        color: #00e5ff !important;
        text-shadow: 0 0 10px #00e5ff;
    }

    .btn-login {
        background: linear-gradient(45deg, #00c6ff, #0072ff);
        border-radius: 30px;
        padding: 6px 18px;
        color: white !important;
    }

    .user-greeting {
        color: #00e5ff;
        font-weight: 500;
        margin-right: 15px;
    }

    .dropdown-menu {
        background: rgba(0,0,0,0.85);
        border-radius: 12px;
        box-shadow: 0 0 20px rgba(0,255,255,0.25);
    }

    .dropdown-item {
        color: #ddd;
        transition: 0.3s;
    }

    .dropdown-item:hover {
        background: transparent;
        color: #00e5ff;
        text-shadow: 0 0 10px #00e5ff;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">

        <!-- ===============================
             LOGO → VỀ HOME USER
             =============================== -->
        <a class="navbar-brand" href="<%= request.getContextPath() %>/user/home">
            🎬 VideoShare
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#mainMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">

            <!-- ===============================
                 MENU BÊN TRÁI
                 =============================== -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <!-- Trang chủ (ai cũng thấy) -->
                <li class="nav-item">
                    <a class="nav-link" href="<%= request.getContextPath() %>/user/home">
                        <i class="fas fa-home"></i> Trang chủ
                    </a>
                </li>

                <!-- Yêu thích (chỉ khi login) -->
                <% if (user != null) { %>
                <li class="nav-item">
                    <a class="nav-link" href="<%= request.getContextPath() %>/views/user/favorite.jsp">
                        <i class="fas fa-heart"></i> Yêu thích
                    </a>
                </li>
                <% } %>

                <!-- ===============================
                     MENU ADMIN (CHỈ ADMIN)
                     =============================== -->
                <% if (user != null && user.isAdmin()) { %>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle"
                       href="#"
                       role="button"
                       data-bs-toggle="dropdown">
                        <i class="fas fa-cogs"></i> Quản lý
                    </a>

                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item"
                               href="<%= request.getContextPath() %>/admin/video">
                                <i class="fas fa-video"></i> Quản lý tiểu phẩm
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item"
                               href="<%= request.getContextPath() %>/admin/user">
                                <i class="fas fa-users"></i> Quản lý người dùng
                            </a>
                        </li>
                    </ul>
                </li>
                <% } %>

            </ul>

            <!-- ===============================
                 MENU BÊN PHẢI (AUTH)
                 =============================== -->
            <ul class="navbar-nav ms-auto">

                <% if (user == null) { %>
                    <!-- CHƯA ĐĂNG NHẬP -->
                    <li class="nav-item">
                        <a class="nav-link btn-login"
                           href="<%= request.getContextPath() %>/login">
                            <i class="fas fa-sign-in-alt"></i> Đăng nhập
                        </a>
                    </li>

                <% } else { %>
                    <!-- ĐÃ ĐĂNG NHẬP -->
                    
                    <!-- PROFILE -->
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<%= request.getContextPath() %>/user/profile">
                            <i class="fas fa-user"></i> Hồ sơ
                        </a>
                    </li>

                    <!-- LỜI CHÀO -->
                    <li class="nav-item d-flex align-items-center">
                        <span class="user-greeting">
                            Xin chào, <%= user.getFullname() %>
                            <% if (user.isAdmin()) { %>(Admin)<% } %>
                        </span>
                    </li>

                    <!-- LOGOUT -->
                    <li class="nav-item">
                        <a class="nav-link btn-login"
                           href="<%= request.getContextPath() %>/logout">
                            <i class="fas fa-sign-out-alt"></i> Đăng xuất
                        </a>
                    </li>
                <% } %>

            </ul>
        </div>
    </div>
</nav>

<!-- CHỪA KHOẢNG TRỐNG CHO HEADER FIXED -->
<div style="height:80px;"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
