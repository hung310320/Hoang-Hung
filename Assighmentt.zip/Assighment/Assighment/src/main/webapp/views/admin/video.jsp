<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Quản lý Super Car</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }
    .admin-card {
        background: rgba(255,255,255,0.08);
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 0 30px rgba(0,255,255,0.25);
        margin-bottom: 30px;
    }
    .form-control, textarea {
        background: transparent;
        border: 1px solid #00e5ff;
        color: white;
        border-radius: 20px;
    }
    .form-control::placeholder, textarea::placeholder { color: #bbb; }
    .form-control:focus, textarea:focus {
        background: transparent;
        color: white;
        box-shadow: 0 0 10px #00e5ff;
        border-color: #00e5ff;
    }
    table { color: white; }
    table thead { background: rgba(0,0,0,0.6); }
    table tbody tr:hover { background: rgba(0,255,255,0.05); }
    .btn { border-radius: 30px; }
    img.poster {
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,255,255,0.3);
    }
</style>

<div class="container">
    <h2 class="mb-4 text-center">🎬 Quản lý Super Car</h2>

    <!-- ================= FORM THÊM / SỬA / XÓA VIDEO ================= -->
    <div class="admin-card">
        <!-- action/method để submit lên Servlet -->
        <form action="<%= request.getContextPath() %>/admin/video" method="post" id="videoForm">

            <div class="row g-3">

                <!-- ID VIDEO -->
                <div class="col-md-6">
                    <input type="text"
                           class="form-control"
                           id="videoId"
                           name="id"
                           placeholder="Video ID (VD: V01)">
                </div>

                <!-- TIÊU ĐỀ -->
                <div class="col-md-6">
                    <input type="text"
                           class="form-control"
                           id="videoTitle"
                           name="title"
                           placeholder="Tiêu đề tiểu phẩm">
                </div>

                <!-- POSTER -->
                <div class="col-md-6">
                    <input type="text"
                           class="form-control"
                           id="videoPoster"
                           name="poster"
                           placeholder="Link poster (jpg/png)">
                </div>

                <!-- LINK VIDEO -->
                <div class="col-md-6">
                    <input type="text"
                           class="form-control"
                           id="videoLink"
                           name="link"
                           placeholder="Link video (YouTube)">
                </div>

                <!-- MÔ TẢ -->
                <div class="col-12">
                    <textarea class="form-control"
                              id="videoDesc"
                              name="description"
                              rows="3"
                              placeholder="Mô tả nội dung tiểu phẩm"></textarea>
                </div>

            </div>

            <!-- NÚT (submit thật) -->
            <div class="text-center mt-4">
                <!-- mỗi nút gửi kèm tham số action -->
                <button type="submit" name="action" value="insert" class="btn btn-success me-2">
                    <i class="fas fa-plus"></i> Thêm
                </button>

                <button type="submit" name="action" value="update" class="btn btn-warning me-2">
                    <i class="fas fa-edit"></i> Sửa
                </button>

                <button type="submit" name="action" value="delete" class="btn btn-danger"
                        onclick="return confirm('Bạn chắc chắn muốn xóa video này?');">
                    <i class="fas fa-trash"></i> Xóa
                </button>

                <button type="button" class="btn btn-secondary ms-2" onclick="clearForm()">
                    Làm mới
                </button>
            </div>

        </form>
    </div>

    <!-- ================= BẢNG DANH SÁCH VIDEO ================= -->
    <div class="admin-card">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead>
            <tr>
                <th>ID</th>
                <th>Poster</th>
                <th>Tiêu đề</th>
                <th>Lượt thích</th>
                <th>Hành động</th>
            </tr>
            </thead>

            <tbody>
            <%-- DEMO UI – SAU NÀY LẤY TỪ DB --%>
            <% for (int i = 1; i <= 5; i++) { 
                   String id = "V0" + i;
                   String title = "Super Car " + i;
                   String poster = "https://picsum.photos/120/80?random=" + i;
                   String link = "https://www.youtube.com/watch?v=demo" + i;
                   String desc = "Mô tả demo " + i;
            %>
            <tr>
                <td><%= id %></td>

                <td>
                    <img class="poster" src="<%= poster %>">
                </td>

                <td><%= title %></td>

                <td>
                    <span class="badge bg-info">
                        <%= (int)(Math.random() * 100) %> ❤
                    </span>
                </td>

                <td>
                    <!-- Đổ dữ liệu lên form để sửa -->
                    <button type="button" class="btn btn-sm btn-outline-warning"
                            onclick="fillForm('<%= id %>','<%= title %>','<%= poster %>','<%= link %>','<%= desc %>')">
                        <i class="fas fa-edit"></i>
                    </button>

                    <!-- Xóa 1 dòng: submit form bằng JS -->
                    <button type="button" class="btn btn-sm btn-outline-danger"
                            onclick="deleteRow('<%= id %>')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <% } %>
            </tbody>
        </table>
    </div>
</div>

<script>
    function fillForm(id, title, poster, link, desc) {
        document.getElementById("videoId").value = id;
        document.getElementById("videoTitle").value = title;
        document.getElementById("videoPoster").value = poster;
        document.getElementById("videoLink").value = link;
        document.getElementById("videoDesc").value = desc;

        // cuộn lên form cho tiện
        document.getElementById("videoForm").scrollIntoView({behavior: "smooth", block: "start"});
    }

    function clearForm() {
        document.getElementById("videoId").value = "";
        document.getElementById("videoTitle").value = "";
        document.getElementById("videoPoster").value = "";
        document.getElementById("videoLink").value = "";
        document.getElementById("videoDesc").value = "";
    }

    function deleteRow(id) {
        if (!confirm("Bạn chắc chắn muốn xóa " + id + " ?")) return;

        // set id vào form rồi submit với action=delete
        document.getElementById("videoId").value = id;

        const form = document.getElementById("videoForm");
        const hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "action";
        hidden.value = "delete";
        form.appendChild(hidden);

        form.submit();
    }
</script>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
