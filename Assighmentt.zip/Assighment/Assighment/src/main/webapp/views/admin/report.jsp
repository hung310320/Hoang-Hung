<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Báo cáo thống kê</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    .admin-card {
        background: rgba(255,255,255,0.08);
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 0 30px rgba(0,255,255,0.25);
    }

    .nav-tabs .nav-link {
        color: #00e5ff;
        border-radius: 20px 20px 0 0;
    }

    .nav-tabs .nav-link.active {
        background: rgba(0,0,0,0.6);
        color: white;
    }

    table {
        color: white;
    }

    table thead {
        background: rgba(0,0,0,0.6);
    }

    select {
        background: transparent;
        color: white;
        border-radius: 20px;
        border: 1px solid #00e5ff;
        padding: 5px 15px;
    }
</style>

<div class="container">
    <h2 class="mb-4 text-center">📊 Báo cáo - Thống kê</h2>

    <div class="admin-card">
        <!-- Tabs -->
        <ul class="nav nav-tabs mb-4" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#fav">
                    Favorites
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#favUser">
                    Favorite Users
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#share">
                    Shared Friends
                </button>
            </li>
        </ul>

        <div class="tab-content">

            <!-- TAB 1: FAVORITES -->
            <div class="tab-pane fade show active" id="fav">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Video Title</th>
                            <th>Favorite Count</th>
                            <th>Latest Date</th>
                            <th>Oldest Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for(int i=1;i<=5;i++){ %>
                        <tr>
                            <td>Super Car <%=i%></td>
                            <td><%= (int)(Math.random()*100) %></td>
                            <td>01/01/2026</td>
                            <td>20/12/2025</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>

            <!-- TAB 2: FAVORITE USERS -->
            <div class="tab-pane fade" id="favUser">
                <div class="mb-3">
                    <label>Chọn video:</label>
                    <select>
                        <option>Super Car 1</option>
                        <option>Super Car 2</option>
                        <option>Super Car 3</option>
                    </select>
                </div>

                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Like Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for(int i=1;i<=4;i++){ %>
                        <tr>
                            <td>user<%=i%>@gmail.com</td>
                            <td>05/01/2026</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>

            <!-- TAB 3: SHARED FRIENDS -->
            <div class="tab-pane fade" id="share">
                <div class="mb-3">
                    <label>Chọn video:</label>
                    <select>
                        <option>Super Car 1</option>
                        <option>Super Car 2</option>
                        <option>Super Car 3</option>
                    </select>
                </div>

                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Sender Email</th>
                            <th>Receiver Email</th>
                            <th>Sent Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for(int i=1;i<=4;i++){ %>
                        <tr>
                            <td>admin@gmail.com</td>
                            <td>friend<%=i%>@gmail.com</td>
                            <td>06/01/2026</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
