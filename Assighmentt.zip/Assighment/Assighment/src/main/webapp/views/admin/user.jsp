<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="poly.entity.User" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Quản lý người dùng</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    /* ===== NỀN GALAXY ===== */
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    /* ===== CARD ADMIN ===== */
    .admin-card {
        background: rgba(255,255,255,0.08);
        border-radius: 22px;
        padding: 25px;
        box-shadow: 0 0 35px rgba(0,255,255,0.25);
    }

    /* ===== TABLE ===== */
    table {
        color: white;
    }

    table thead {
        background: rgba(0,0,0,0.65);
    }

    table tbody tr {
        transition: 0.3s;
    }

    table tbody tr:hover {
        background: rgba(0,255,255,0.06);
    }

    /* ===== BADGE ===== */
    .badge {
        padding: 6px 14px;
        border-radius: 20px;
        font-weight: 500;
        letter-spacing: 0.5px;
    }

    /* ===== BUTTON ===== */
    .btn {
        border-radius: 30px;
        transition: 0.3s;
    }

    .btn-outline-warning:hover {
        box-shadow: 0 0 15px rgba(255,193,7,0.8);
    }

    .btn-outline-success:hover {
        box-shadow: 0 0 15px rgba(25,135,84,0.8);
    }
</style>

<div class="container">
    <h2 class="mb-4 text-center">👤 Quản lý Người dùng</h2>

    <div class="admin-card">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Vai trò</th>
                    <th>Trạng thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>

            <tbody>
            <%
                List<User> users = (List<User>) request.getAttribute("users");

                if (users != null && !users.isEmpty()) {
                    for (User u : users) {
            %>
                <tr>

                    <!-- EMAIL -->
                    <td><%= u.getEmail() %></td>

                    <!-- ROLE -->
                    <td>
                        <span class="badge <%= u.isAdmin() ? "bg-danger" : "bg-info" %>">
                            <%= u.isAdmin() ? "ADMIN" : "USER" %>
                        </span>
                    </td>

                    <!-- STATUS -->
                    <td>
                        <span class="badge <%= u.isActive() ? "bg-success" : "bg-secondary" %>">
                            <%= u.isActive() ? "Active" : "Disabled" %>
                        </span>
                    </td>

                    <!-- ACTION -->
                    <td>
                        <%-- Không cho khóa admin --%>
                        <% if (!u.isAdmin()) { %>

                            <% if (u.isActive()) { %>
                                <!-- DISABLE -->
                                <form action="<%=request.getContextPath()%>/admin/user/action"
                                      method="post" style="display:inline">
                                    <input type="hidden" name="id" value="<%=u.getId()%>">
                                    <input type="hidden" name="action" value="disable">
                                    <button class="btn btn-sm btn-outline-warning">
                                        <i class="fas fa-user-lock"></i> Disable
                                    </button>
                                </form>
                            <% } else { %>
                                <!-- ENABLE -->
                                <form action="<%=request.getContextPath()%>/admin/user/action"
                                      method="post" style="display:inline">
                                    <input type="hidden" name="id" value="<%=u.getId()%>">
                                    <input type="hidden" name="action" value="enable">
                                    <button class="btn btn-sm btn-outline-success">
                                        <i class="fas fa-user-check"></i> Enable
                                    </button>
                                </form>
                            <% } %>

                        <% } %>
                    </td>

                </tr>
            <%
                    }
                } else {
            %>
                <tr>
                    <td colspan="4">Không có người dùng</td>
                </tr>
            <%
                }
            %>
            </tbody>
        </table>
    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
