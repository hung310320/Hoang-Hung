<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="poly.entity.User" %>

<!DOCTYPE html>
<html>
<head>
    <title>Hồ sơ cá nhân</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<%
    // Lấy user từ session (KHÔNG khai báo trùng với header.jsp)
    User currentUser = (User) session.getAttribute("user");
%>

<style>
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    .profile-card {
        max-width: 500px;
        margin: auto;
        background: rgba(255,255,255,0.08);
        padding: 30px;
        border-radius: 25px;
        box-shadow: 0 0 30px rgba(0,255,255,0.25);
    }

    .profile-item {
        margin-bottom: 15px;
        font-size: 16px;
    }

    .profile-label {
        color: #00e5ff;
        font-weight: bold;
    }
</style>

<div class="container">
    <h2 class="text-center mb-4">👤 Hồ sơ cá nhân</h2>

    <div class="profile-card">

        <% if (currentUser == null) { %>
            <!-- CHƯA LOGIN -->
            <div class="text-center text-danger">
                Bạn chưa đăng nhập!
            </div>
        <% } else { %>

            <!-- EMAIL -->
            <div class="profile-item">
                <span class="profile-label">Email:</span>
                <%= currentUser.getEmail() %>
            </div>

            <!-- FULL NAME -->
            <div class="profile-item">
                <span class="profile-label">Họ tên:</span>
                <%= currentUser.getFullname() %>
            </div>

            <!-- ROLE -->
            <div class="profile-item">
                <span class="profile-label">Vai trò:</span>
                <%= currentUser.isAdmin() ? "ADMIN" : "USER" %>
            </div>

        <% } %>

    </div>
</div>

<%@ include file="../layout/footer.jsp" %>
</body>
</html>
