<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Quên mật khẩu</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    .auth-card {
        max-width: 420px;
        margin: auto;
        background: rgba(255,255,255,0.08);
        padding: 40px;
        border-radius: 25px;
        box-shadow: 0 0 30px rgba(0,255,255,0.25);
    }

    .auth-card h3 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: bold;
    }

    .form-control {
        background: transparent;
        border-radius: 30px;
        color: white;
        border: 1px solid #00e5ff;
    }

    .form-control::placeholder {
        color: #bbb;
    }

    .form-control:focus {
        background: transparent;
        color: white;
        box-shadow: 0 0 10px #00e5ff;
        border-color: #00e5ff;
    }

    .btn-reset {
        width: 100%;
        border-radius: 30px;
        padding: 10px;
        background: linear-gradient(45deg, #ff512f, #dd2476);
        color: white;
        font-weight: bold;
    }

    .auth-links a {
        color: #00e5ff;
        text-decoration: none;
        font-size: 14px;
    }

    .auth-links a:hover {
        text-decoration: underline;
    }
</style>

<div class="container">
    <div class="auth-card">
        <h3>🔑 Quên mật khẩu</h3>

        <form>
            <div class="mb-3">
                <input type="email" class="form-control" placeholder="Nhập email của bạn">
            </div>

            <button type="submit" class="btn btn-reset">
                Gửi lại mật khẩu
            </button>
        </form>

        <div class="auth-links text-center mt-3">
            <a href="login.jsp">Quay lại đăng nhập</a>
        </div>
    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
