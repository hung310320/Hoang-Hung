<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Đăng ký</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    /* ===== NỀN ĐEN GALAXY ===== */
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    .auth-card {
        max-width: 450px;
        margin: auto;
        background: rgba(255,255,255,0.08);
        padding: 40px;
        border-radius: 25px;
        box-shadow: 0 0 30px rgba(0,255,255,0.25);
    }

    .auth-card h3 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: bold;
    }

    .form-control {
        background: transparent;
        border-radius: 30px;
        color: white;
        border: 1px solid #00e5ff;
    }

    .form-control::placeholder {
        color: #bbb;
    }

    .form-control:focus {
        background: transparent;
        color: white;
        box-shadow: 0 0 10px #00e5ff;
        border-color: #00e5ff;
    }

    .btn-register {
        width: 100%;
        border-radius: 30px;
        padding: 10px;
        background: linear-gradient(45deg, #00c6ff, #0072ff);
        color: white;
        font-weight: bold;
    }

    .btn-register:hover {
        box-shadow: 0 0 15px #00e5ff;
    }

    .auth-links a {
        color: #00e5ff;
        text-decoration: none;
        font-size: 14px;
    }

    .auth-links a:hover {
        text-decoration: underline;
    }
</style>

<div class="container">
    <div class="auth-card">
        <h3>📝 Đăng ký</h3>

        <!-- HIỂN THỊ THÔNG BÁO LỖI -->
        <%
            String msg = (String) request.getAttribute("message");
            if (msg != null) {
        %>
            <div style="color:#ff6b6b; text-align:center; margin-bottom:15px">
                <%= msg %>
            </div>
        <% } %>

        <!-- FORM ĐĂNG KÝ -->
        <form action="<%= request.getContextPath() %>/register" method="post">

            <div class="mb-3">
                <input type="email"
                       name="email"
                       class="form-control"
                       placeholder="Email"
                       required>
            </div>

            <div class="mb-3">
                <input type="text"
                       name="fullname"
                       class="form-control"
                       placeholder="Họ và tên"
                       required>
            </div>

            <div class="mb-3">
                <input type="password"
                       name="password"
                       class="form-control"
                       placeholder="Mật khẩu"
                       required>
            </div>

            <div class="mb-3">
                <input type="password"
                       name="confirm"
                       class="form-control"
                       placeholder="Xác nhận mật khẩu"
                       required>
            </div>

            <button type="submit" class="btn btn-register">
                Đăng ký
            </button>
        </form>

        <div class="auth-links text-center mt-3">
            <a href="<%= request.getContextPath() %>/login">
                Đã có tài khoản? Đăng nhập
            </a>
        </div>
    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
