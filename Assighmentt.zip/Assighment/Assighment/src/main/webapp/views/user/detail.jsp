<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Chi tiết Super Car</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    /* ===== NỀN GALAXY ===== */
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    /* ===== CARD VIDEO ===== */
    .video-wrapper {
        background: rgba(255,255,255,0.08);
        border-radius: 25px;
        padding: 30px;
        box-shadow: 0 0 35px rgba(0,255,255,0.25);
        margin-bottom: 60px;
    }

    /* VIDEO */
    .video-wrapper iframe {
        width: 100%;
        height: 420px;
        border-radius: 18px;
        box-shadow: 0 0 25px rgba(0,0,0,0.8);
    }

    /* TITLE */
    .video-title {
        font-size: 28px;
        font-weight: bold;
        margin-top: 25px;
        color: #00e5ff;
    }

    /* DESC */
    .video-desc {
        margin-top: 15px;
        color: #ccc;
        line-height: 1.8;
        font-size: 16px;
    }

    /* ACTION */
    .action-btn {
        border-radius: 50px;
        padding: 10px 25px;
        margin-right: 10px;
        transition: 0.3s;
    }

    .btn-outline-danger:hover {
        box-shadow: 0 0 18px rgba(220,53,69,0.8);
    }

    .btn-outline-success:hover {
        box-shadow: 0 0 18px rgba(25,135,84,0.8);
    }

    .btn-outline-info:hover {
        box-shadow: 0 0 18px rgba(13,202,240,0.8);
    }
</style>

<div class="container">
    <div class="video-wrapper">

        <!-- VIDEO -->
        <iframe width="560" height="315" src="https://www.youtube.com/embed/RswMbi_wEeI?si=0273t9JTB2d0QEV_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

        <!-- TITLE -->
        <div class="video-title">
            🎬 Super Car
        </div>

        <!-- DESCRIPTION -->
        <div class="video-desc">
             Đây là nội dung tập trung vào những siêu xe đỉnh cao, nơi sức mạnh, tốc độ và đẳng cấp được đẩy lên giới hạn.
            <br>
           Phù hợp để giải trí và bùng nổ cảm xúc sau những giờ học tập và làm việc căng thẳng.
        </div>

        <!-- ACTION -->
        <div class="mt-4">
            <button class="btn btn-outline-danger action-btn">
                <i class="fas fa-heart"></i> Like
            </button>

            <button class="btn btn-outline-success action-btn">
                <i class="fas fa-share"></i> Share
            </button>

            <a href="<%= request.getContextPath() %>/user/home"
               class="btn btn-outline-info action-btn">
                <i class="fas fa-arrow-left"></i> Quay lại
            </a>
        </div>

    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
