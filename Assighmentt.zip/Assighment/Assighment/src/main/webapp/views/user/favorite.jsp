<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Yêu thích</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    /* ===== NỀN ĐEN GALAXY ===== */
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    /* CARD */
    .fav-card {
        background: rgba(255,255,255,0.08);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 0 20px rgba(255,0,0,0.15);
        transition: 0.3s;
    }

    .fav-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0 30px rgba(255,0,0,0.35);
    }

    /* VIDEO GIẢ */
    .fav-thumb {
        height: 200px;
        background: #000;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* PLAY ICON */
    .play-icon {
        width: 60px;
        height: 60px;
        background: rgba(255,0,0,0.9);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: white;
        transition: 0.3s;
    }

    .fav-thumb:hover .play-icon {
        transform: scale(1.15);
        box-shadow: 0 0 20px red;
    }

    /* BODY */
    .fav-body {
        padding: 15px;
        text-align: center;
    }

    .fav-title {
        font-weight: bold;
        margin-bottom: 10px;
    }

    .btn-unlike {
        border-radius: 30px;
    }
</style>

<div class="container">
    <h2 class="mb-4 text-center">❤️ Super Car yêu thích</h2>

    <div class="row g-4">
        <% for (int i = 1; i <= 4; i++) { %>
        <div class="col-md-3">
            <div class="fav-card">

                <!-- VIDEO GIẢ -->
                <a href="detail.jsp" style="text-decoration:none">
                    <div class="fav-thumb">
                        <div class="play-icon">
                            <i class="fas fa-play"></i>
                        </div>
                    </div>
                </a>

                <!-- BODY -->
                <div class="fav-body">
                    <div class="fav-title">
                        Super Car yêu thích <%=i%>
                    </div>

                    <a href="detail.jsp" class="btn btn-sm btn-outline-info">
                        <i class="fas fa-eye"></i> Xem
                    </a>

                    <button class="btn btn-sm btn-outline-danger btn-unlike">
                        <i class="fas fa-times"></i> Unlike
                    </button>
                </div>

            </div>
        </div>
        <% } %>
    </div>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
