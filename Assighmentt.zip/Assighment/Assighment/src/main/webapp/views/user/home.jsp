<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Trang chủ - Video Sharing</title>
</head>
<body>

<%@ include file="../layout/header.jsp" %>

<style>
    body {
        background: radial-gradient(circle at top, #1b2735, #090a0f);
        color: white;
        min-height: 100vh;
    }

    .home-wrapper {
        padding-bottom: 60px;
    }

    .video-card {
        background: rgba(255,255,255,0.08);
        border-radius: 20px;
        overflow: hidden;
        transition: 0.3s;
        box-shadow: 0 0 20px rgba(0,255,255,0.15);
    }

    .video-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0 30px rgba(0,255,255,0.35);
    }

    .video-thumb {
        height: 220px;
        background: #000;
        border-radius: 20px 20px 0 0;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .play-icon {
        width: 65px;
        height: 65px;
        background: rgba(255,0,0,0.9);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 26px;
        transition: 0.3s;
    }

    .video-thumb:hover .play-icon {
        transform: scale(1.15);
        box-shadow: 0 0 20px red;
    }

    .video-body {
        padding: 15px;
    }

    .video-title {
        font-weight: bold;
        margin-bottom: 10px;
    }

    .video-actions .btn {
        border-radius: 30px;
        padding: 5px 14px;
        font-size: 14px;
    }

    .pagination .page-link {
        background: transparent;
        border: 1px solid #00e5ff;
        color: #00e5ff;
        margin: 0 5px;
        border-radius: 50px;
    }

    .pagination .page-link:hover {
        background: #00e5ff;
        color: black;
    }
</style>

<div class="container home-wrapper">
    <h2 class="mb-4 text-center">Super Car nổi bật</h2>

    <div class="row g-4">
        <% for (int i = 1; i <= 6; i++) { %>
        <div class="col-md-4">
            <div class="video-card">

                <!-- CLICK VÀO VIDEO -->
                <a href="<%= request.getContextPath() %>/views/user/detail.jsp"
                   style="text-decoration:none">
                    <div class="video-thumb">
                        <div class="play-icon">
                            <i class="fas fa-play"></i>
                        </div>
                    </div>
                </a>

                <div class="video-body">
                    <div class="video-title">
                        Super Car <%=i%>
                    </div>

                    <div class="video-actions">
                        <a href="<%= request.getContextPath() %>/views/user/detail.jsp"
                           class="btn btn-sm btn-outline-info">
                            <i class="fas fa-eye"></i> Xem
                        </a>

                        <button class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-heart"></i> Like
                        </button>

                        <button class="btn btn-sm btn-outline-success">
                            <i class="fas fa-share"></i> Share
                        </button>
                    </div>
                </div>

            </div>
        </div>
        <% } %>
    </div>

    <nav class="mt-5">
        <ul class="pagination justify-content-center">
            <li class="page-item"><a class="page-link" href="#">|&lt;</a></li>
            <li class="page-item"><a class="page-link" href="#">&lt;</a></li>
            <li class="page-item"><a class="page-link" href="#">&gt;</a></li>
            <li class="page-item"><a class="page-link" href="#">&gt;|</a></li>
        </ul>
    </nav>
</div>

<%@ include file="../layout/footer.jsp" %>

</body>
</html>
