<%@ page contentType="text/html; charset=UTF-8" %>
<%
    // Khi chạy project → vào thẳng trang người dùng
    response.sendRedirect("views/user/home.jsp");
%>
