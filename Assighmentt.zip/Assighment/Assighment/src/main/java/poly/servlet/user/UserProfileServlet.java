package poly.servlet.user;

import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;
import poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * UserProfileServlet
 * -------------------------
 * - Hiển thị hồ sơ user
 * - Cập nhật fullname / password
 */
@WebServlet("/user/profile")
public class UserProfileServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/views/user/profile.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String fullname = request.getParameter("fullname");
        String password = request.getParameter("password");

        user.setFullname(fullname);

        if (password != null && !password.isBlank()) {
            user.setPassword(password); // (sau này mã hóa)
        }

        userDAO.update(user);

        session.setAttribute("user", user);

        request.setAttribute("message", "Cập nhật hồ sơ thành công!");
        request.getRequestDispatcher("/views/user/profile.jsp")
               .forward(request, response);
    }
}
