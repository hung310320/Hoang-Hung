package poly.servlet;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;

@WebServlet("/admin/user/action")
public class AdminUserActionServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String id = request.getParameter("id");
        String action = request.getParameter("action");

        if ("disable".equals(action)) {
            userDAO.updateActive(id, false);
        } else if ("enable".equals(action)) {
            userDAO.updateActive(id, true);
        }

        response.sendRedirect(request.getContextPath() + "/admin/user");
    }
}
