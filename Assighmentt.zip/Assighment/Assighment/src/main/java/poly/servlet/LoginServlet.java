package poly.servlet;

import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;
import poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * LoginServlet
 * -------------------------------
 * - Xử lý đăng nhập
 * - Kiểm tra tài khoản bị khóa
 * - Phân quyền ADMIN / USER
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/views/user/login.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /* ========== 1. LẤY DỮ LIỆU ========== */
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        /* ========== 2. KIỂM TRA USER ========== */
        User user = userDAO.findByEmailAndPassword(email, password);

        if (user == null) {
            request.setAttribute("message", "Sai email hoặc mật khẩu!");
            request.getRequestDispatcher("/views/user/login.jsp")
                   .forward(request, response);
            return;
        }

        /* ========== 3. KIỂM TRA ACTIVE (DISABLE) ========== */
        if (!user.isActive()) {
            request.setAttribute("message", "Tài khoản của bạn đã bị khóa!");
            request.getRequestDispatcher("/views/user/login.jsp")
                   .forward(request, response);
            return;
        }

        /* ========== 4. TẠO SESSION ========== */
        HttpSession session = request.getSession();
        session.setAttribute("user", user);
        session.setAttribute("role", user.isAdmin() ? "ADMIN" : "USER");

        /* ========== 5. ĐIỀU HƯỚNG ========== */
        if (user.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/admin/user");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/home");
        }
    }
}
