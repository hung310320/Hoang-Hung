package poly.servlet;

import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;
import poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * RegisterServlet
 * ------------------------------------------------
 * Chức năng:
 * - Hiển thị trang đăng ký (GET)
 * - Xử lý đăng ký (POST)
 * - Lưu user mới vào database
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/views/user/register.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String fullname = request.getParameter("fullname");
        String password = request.getParameter("password");
        String confirm = request.getParameter("confirm");

        // Kiểm tra xác nhận mật khẩu
        if (!password.equals(confirm)) {
            request.setAttribute("message", "Mật khẩu xác nhận không khớp!");
            request.getRequestDispatcher("/views/user/register.jsp")
                   .forward(request, response);
            return;
        }

        // Kiểm tra email đã tồn tại
        if (userDAO.findByEmail(email) != null) {
            request.setAttribute("message", "Email đã tồn tại!");
            request.getRequestDispatcher("/views/user/register.jsp")
                   .forward(request, response);
            return;
        }

        // Tạo user mới
        String newId = userDAO.getNextUserId();

        User user = new User();
        user.setId(newId);
        user.setEmail(email);
        user.setFullname(fullname);
        user.setPassword(password);
        user.setAdmin(false);

        // (gợi ý) set active luôn nếu DB cho phép null thì khỏi set cũng được,
        // nhưng thường nên set true để đăng nhập được ngay:
        // user.setActive(true);

        // Lưu DB
        userDAO.create(user);

        response.sendRedirect(request.getContextPath() + "/login");
    }
}
