package poly.servlet;

import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;
import poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * =========================================================
 * AdminUserServlet
 * =========================================================
 * Chức năng:
 * - Chỉ dành cho ADMIN (đã được bảo vệ bởi AuthFilter)
 * - Lấy danh sách người dùng từ database
 * - Gửi dữ liệu sang trang user.jsp để hiển thị
 *
 * URL mapping:
 *   /admin/user
 * =========================================================
 */
@WebServlet("/admin/user")
public class AdminUserServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<User> users = userDAO.findAll();
        System.out.println("ADMIN USER PAGE - TOTAL USERS = " + users.size());

        request.setAttribute("users", users);

        request.getRequestDispatcher("/views/admin/user.jsp")
               .forward(request, response);
    }
}
