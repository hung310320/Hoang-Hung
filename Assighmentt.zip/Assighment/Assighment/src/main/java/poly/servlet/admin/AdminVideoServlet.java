package poly.servlet.admin;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/admin/video")
public class AdminVideoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/views/admin/video.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action"); // insert/update/delete
        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String poster = request.getParameter("poster");
        String link = request.getParameter("link");
        String description = request.getParameter("description");

        // TODO: gọi DAO xử lý DB
        if ("insert".equalsIgnoreCase(action)) {
            // videoDAO.insert(...)
        } else if ("update".equalsIgnoreCase(action)) {
            // videoDAO.update(...)
        } else if ("delete".equalsIgnoreCase(action)) {
            // videoDAO.delete(id)
        }

        // quay lại trang GET tránh submit lại khi refresh
        response.sendRedirect(request.getContextPath() + "/admin/video");
    }
}
