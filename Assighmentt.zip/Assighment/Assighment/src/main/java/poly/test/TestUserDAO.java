package poly.test;
import poly.dao.UserDAO;
import poly.daoimpl.UserDAOImpl;
import poly.entity.User;

public class TestUserDAO {
    public static void main(String[] args) {
        UserDAO dao = new UserDAOImpl();

        User u = dao.findByEmailAndPassword("teo@gmail.com", "123");

        if (u != null) {
            System.out.println("Login OK: " + u.getFullname());
            System.out.println("Admin: " + u.isAdmin());
        } else {
            System.out.println("Login FAIL");
        }
    }
}

