package poly.test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import poly.util.JpaUtil;

public class TestJPA {

    public static void main(String[] args) {

        EntityManager em = null;

        try {
            // 1. Lấy EntityManager
            em = JpaUtil.getEntityManager();
            System.out.println("✅ Tạo EntityManager thành công!");

            // 2. Test query đơn giản (lấy số user)
            Query query = em.createQuery("SELECT COUNT(u) FROM User u");
            Long count = (Long) query.getSingleResult();

            System.out.println("✅ Số user trong DB: " + count);
            System.out.println("🎉 KẾT NỐI DATABASE OK!");

        } catch (Exception e) {
            System.err.println("❌ KẾT NỐI DATABASE THẤT BẠI!");
            e.printStackTrace();
        } finally {
            // 3. Đóng EntityManager
            if (em != null && em.isOpen()) {
                em.close();
            }

            // 4. Đóng EntityManagerFactory
            JpaUtil.shutdown();
        }
    }
}
