package poly.test;
import poly.dao.FavoriteDAO;
import poly.daoimpl.FavoriteDAOImpl;

public class TestFavoriteDAO {
    public static void main(String[] args) {

        FavoriteDAO dao = new FavoriteDAOImpl();

        System.out.println("Report số lượt like:");
        dao.countFavoriteByVideo().forEach(o -> {
            System.out.println(o[0] + " - " + o[1] + " - " + o[2]);
        });
    }
}

