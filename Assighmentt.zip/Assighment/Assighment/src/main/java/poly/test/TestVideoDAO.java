package poly.test;

import poly.dao.VideoDAO;
import poly.daoimpl.VideoDAOImpl;

public class TestVideoDAO {
    public static void main(String[] args) {

        VideoDAO dao = new VideoDAOImpl();

        System.out.println("Danh sách video active:");
        dao.findActiveVideos().forEach(v -> {
            System.out.println(v.getId() + " - " + v.getTitle());
        });
    }
}

