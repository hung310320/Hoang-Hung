package poly.test;
import poly.dao.ShareDAO;
import poly.daoimpl.ShareDAOImpl;

public class TestShareDAO {
    public static void main(String[] args) {

        ShareDAO dao = new ShareDAOImpl();

        System.out.println("Report video được share:");
        dao.reportSharedVideos().forEach(o -> {
            System.out.println(o[0] + " - " + o[1] + " - " + o[2]);
        });
    }
}

