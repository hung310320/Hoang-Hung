package poly.daoimpl;

import poly.dao.UserDAO;
import poly.entity.User;
import poly.util.JpaUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class UserDAOImpl implements UserDAO {

    @Override
    public void create(User user) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(user);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public void update(User user) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(user);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public void delete(String id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            User user = em.find(User.class, id);
            if (user != null) {
                em.remove(user);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public User findById(String id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(User.class, id);
        } finally {
            em.close();
        }
    }

    @Override
    public List<User> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql = "SELECT u FROM User u";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    @Override
    public User findByEmailAndPassword(String email, String password) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql = "SELECT u FROM User u WHERE u.email = :email AND u.password = :password";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("email", email);
            query.setParameter("password", password);

            return query.getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }

    @Override
    public User findByEmail(String email) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql = "SELECT u FROM User u WHERE u.email = :email";
            return em.createQuery(jpql, User.class)
                     .setParameter("email", email)
                     .getSingleResult();
        } catch (Exception e) {
            return null; // không tìm thấy
        } finally {
            em.close();
        }
    }

    @Override
    public String getNextUserId() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql = "SELECT u.id FROM User u ORDER BY u.id DESC";
            List<String> ids = em.createQuery(jpql, String.class)
                                 .setMaxResults(1)
                                 .getResultList();

            if (ids.isEmpty()) {
                return "U01";
            }

            String lastId = ids.get(0); // VD: U03
            int number = Integer.parseInt(lastId.substring(1));
            return String.format("U%02d", number + 1);

        } finally {
            em.close();
        }
    }

    @Override
    public void setActive(String userId, boolean active) {
        EntityManager em = JpaUtil.getEntityManager();
        EntityTransaction tran = em.getTransaction();

        try {
            tran.begin();

            User user = em.find(User.class, userId);

            if (user != null && !user.isAdmin()) {
                user.setActive(active);
            }

            tran.commit();
        } catch (Exception e) {
            tran.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public void updateActive(String userId, boolean active) {
        EntityManager em = JpaUtil.getEntityManager();
        EntityTransaction tran = em.getTransaction();

        try {
            tran.begin();

            User user = em.find(User.class, userId);
            if (user != null) {
                user.setActive(active);
                em.merge(user);
            }

            tran.commit();
        } catch (Exception e) {
            tran.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
