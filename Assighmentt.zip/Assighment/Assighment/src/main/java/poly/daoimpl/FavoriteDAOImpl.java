package poly.daoimpl;

import poly.dao.FavoriteDAO;
import poly.entity.Favorite;
import poly.util.JpaUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 * FavoriteDAOImpl
 * Cài đặt xử lý Like & Report
 */
public class FavoriteDAOImpl implements FavoriteDAO {

    @Override
    public void create(Favorite favorite) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(favorite);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public void delete(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Favorite f = em.find(Favorite.class, id);
            if (f != null) {
                em.remove(f);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public Favorite findByUserAndVideo(String userId, String videoId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT f FROM Favorite f " +
                "WHERE f.user.id = :uid AND f.video.id = :vid";

            TypedQuery<Favorite> query =
                em.createQuery(jpql, Favorite.class);

            query.setParameter("uid", userId);
            query.setParameter("vid", videoId);

            return query.getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }

    @Override
    public List<Favorite> findByUser(String userId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT f FROM Favorite f WHERE f.user.id = :uid";

            TypedQuery<Favorite> query =
                em.createQuery(jpql, Favorite.class);

            query.setParameter("uid", userId);

            return query.getResultList();
        } finally {
            em.close();
        }
    }

    @Override
    public List<Object[]> countFavoriteByVideo() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT f.video.id, f.video.title, COUNT(f) " +
                "FROM Favorite f " +
                "GROUP BY f.video.id, f.video.title";

            return em.createQuery(jpql, Object[].class)
                     .getResultList();
        } finally {
            em.close();
        }
    }

    @Override
    public List<Object[]> findUsersLikeVideo(String videoId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT f.user.id, f.user.fullname, f.likeDate " +
                "FROM Favorite f " +
                "WHERE f.video.id = :vid";

            return em.createQuery(jpql, Object[].class)
                     .setParameter("vid", videoId)
                     .getResultList();
        } finally {
            em.close();
        }
    }
}
