package poly.daoimpl;

import poly.dao.ShareDAO;
import poly.entity.Share;
import poly.util.JpaUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 * ShareDAOImpl
 * Cài đặt xử lý Share & Report
 */
public class ShareDAOImpl implements ShareDAO {

    @Override
    public void create(Share share) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(share);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public void delete(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Share s = em.find(Share.class, id);
            if (s != null) {
                em.remove(s);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    @Override
    public List<Share> findByVideo(String videoId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT s FROM Share s WHERE s.video.id = :vid";

            TypedQuery<Share> query =
                em.createQuery(jpql, Share.class);

            query.setParameter("vid", videoId);

            return query.getResultList();
        } finally {
            em.close();
        }
    }

    // ================= REPORT =================

    @Override
    public List<Object[]> reportSharedVideos() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT s.video.id, s.video.title, COUNT(s) " +
                "FROM Share s " +
                "GROUP BY s.video.id, s.video.title";

            return em.createQuery(jpql, Object[].class)
                     .getResultList();
        } finally {
            em.close();
        }
    }

    @Override
    public List<Object[]> findShareByVideo(String videoId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            String jpql =
                "SELECT s.emails, s.shareDate, s.user.fullname " +
                "FROM Share s " +
                "WHERE s.video.id = :vid";

            return em.createQuery(jpql, Object[].class)
                     .setParameter("vid", videoId)
                     .getResultList();
        } finally {
            em.close();
        }
    }
}
