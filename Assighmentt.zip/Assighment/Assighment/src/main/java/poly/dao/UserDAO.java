package poly.dao;

import poly.entity.User;
import java.util.List;

public interface UserDAO {

    // Thêm user mới
    void create(User user);

    // Cập nhật user
    void update(User user);

    // Xóa user theo id
    void delete(String id);
    
    User findByEmail(String email);

    // Tìm user theo id
    User findById(String id);
    
    void setActive(String userId, boolean active);


    // Lấy tất cả user
    List<User> findAll();

    // Login (email + password)
    User findByEmailAndPassword(String email, String password);
    
    void updateActive(String userId, boolean active);
    
    String getNextUserId();

}
