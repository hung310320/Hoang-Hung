package poly.dao;

import poly.entity.Video;
import java.util.List;

/**
 * VideoDAO
 * Khai báo các chức năng thao tác với Video
 */
public interface VideoDAO {

    // Thêm video mới
    void create(Video video);

    // Cập nhật video
    void update(Video video);

    // Xóa video theo id
    void delete(String id);

    // Tìm video theo id
    Video findById(String id);

    // Lấy tất cả video
    List<Video> findAll();

    // Lấy các video đang active (dùng cho trang chủ)
    List<Video> findActiveVideos();
}
