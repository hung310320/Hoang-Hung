package poly.dao;

import poly.entity.Share;
import java.util.List;

/**
 * ShareDAO
 * Xử lý chức năng SHARE + REPORT
 */
public interface ShareDAO {

    // Thêm share mới
    void create(Share share);

    // Xóa share
    void delete(Long id);

    // Danh sách share theo video
    List<Share> findByVideo(String videoId);

    // ================= REPORT =================

    // Danh sách video được share
    List<Object[]> reportSharedVideos();

    // Danh sách người nhận share của 1 video
    List<Object[]> findShareByVideo(String videoId);
}
