package poly.dao;

import poly.entity.Favorite;
import poly.entity.Video;

import java.util.List;

/**
 * FavoriteDAO
 * Xử lý chức năng LIKE + REPORT
 */
public interface FavoriteDAO {

    // Thêm like
    void create(Favorite favorite);

    // Xóa like
    void delete(Long id);

    // Tìm favorite theo user + video
    Favorite findByUserAndVideo(String userId, String videoId);

    // Danh sách favorite của 1 user
    List<Favorite> findByUser(String userId);

    // ================= REPORT =================

    // Đếm số lượt like theo video
    List<Object[]> countFavoriteByVideo();

    // Danh sách user đã like 1 video
    List<Object[]> findUsersLikeVideo(String videoId);
}
