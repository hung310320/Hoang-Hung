package poly.filter;

import poly.entity.User;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

/**
 * AuthFilter
 * ------------------------------------------------
 * Chức năng:
 * - Kiểm tra đăng nhập
 * - Phân quyền ADMIN / USER
 * - Chặn truy cập trái phép vào trang admin
 *
 * Áp dụng cho các URL /admin/*
 */
@WebFilter("/admin/*")
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Không cần xử lý gì khi khởi tạo
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        // Ép kiểu về HTTP
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        // Lấy session (false: không tạo mới)
        HttpSession session = req.getSession(false);

        // Nếu chưa có session → chưa đăng nhập
        if (session == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Lấy user từ session
        User user = (User) session.getAttribute("user");

        // Nếu không có user hoặc không phải admin
        if (user == null || !user.isAdmin()) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Nếu là admin → cho đi tiếp
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Không cần xử lý gì khi destroy
    }
}
