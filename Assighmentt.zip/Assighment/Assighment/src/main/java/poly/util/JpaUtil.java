package poly.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * JpaUtil
 * - Tạo EntityManagerFactory 1 lần duy nhất
 * - Cung cấp EntityManager cho DAO
 */
public class JpaUtil {

    // Tên persistence-unit (trùng persistence.xml)
    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("PolyOEEPU");

    /**
     * Lấy EntityManager mới
     */
    public static EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    /**
     * Đóng EntityManagerFactory khi shutdown server
     */
    public static void shutdown() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}
