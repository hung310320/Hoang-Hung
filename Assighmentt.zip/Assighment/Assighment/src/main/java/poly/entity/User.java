package poly.entity;

import jakarta.persistence.*;

import java.util.List;

/**
 * Entity User
 * Mapping với bảng Users trong database
 */
@Entity
@Table(name = "Users")
public class User {

    /* ================= PRIMARY KEY ================= */

    @Id
    @Column(name = "Id", length = 50)
    private String id;

    /* ================= BASIC INFO ================= */

    @Column(name = "Email", nullable = false, unique = true)
    private String email;

    @Column(name = "Password", nullable = false)
    private String password;

    @Column(name = "Fullname")
    private String fullname;

    /* ================= ROLE ================= */

    /**
     * Admin = 1 → ADMIN
     * Admin = 0 → USER
     */
    @Column(name = "Admin")
    private Boolean admin;

    /* ================= STATUS ================= */

    /**
     * Active = 1 → Được phép đăng nhập
     * Active = 0 → Bị khóa (Disable)
     *
     * ⚠️ PHẢI DÙNG Boolean (KHÔNG DÙNG boolean)
     * để tránh lỗi null từ database
     */
    @Column(name = "Active")
    private Boolean active;

    /* ================= RELATION ================= */

    @OneToMany(mappedBy = "user")
    private List<Favorite> favorites;

    @OneToMany(mappedBy = "user")
    private List<Share> shares;

    /* ================= GETTER / SETTER ================= */

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    /* ===== ROLE ===== */

    public Boolean getAdmin() {
        return admin;
    }

    /**
     * Dùng trong JSP / Servlet
     * an toàn kể cả khi admin = null
     */
    public boolean isAdmin() {
        return Boolean.TRUE.equals(admin);
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }

    /* ===== ACTIVE ===== */

    public Boolean getActive() {
        return active;
    }

    /**
     * DÙNG METHOD NÀY TRONG JSP
     * Không bao giờ bị NullPointerException
     */
    public boolean isActive() {
        return Boolean.TRUE.equals(active);
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    /* ===== RELATION ===== */

    public List<Favorite> getFavorites() {
        return favorites;
    }

    public void setFavorites(List<Favorite> favorites) {
        this.favorites = favorites;
    }

    public List<Share> getShares() {
        return shares;
    }

    public void setShares(List<Share> shares) {
        this.shares = shares;
    }
}
