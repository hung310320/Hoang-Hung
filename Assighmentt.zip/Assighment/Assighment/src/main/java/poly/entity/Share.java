package poly.entity;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entity Share
 * → Lưu lịch sử chia sẻ video
 */
@Entity
@Table(name = "Shares")
public class Share {

    /**
     * Khóa chính tự tăng
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long id;

    /**
     * Người thực hiện chia sẻ
     */
    @ManyToOne
    @JoinColumn(name = "UserId", nullable = false)
    private User user;

    /**
     * Video được chia sẻ
     */
    @ManyToOne
    @JoinColumn(name = "VideoId", nullable = false)
    private Video video;

    /**
     * Email người nhận
     */
    @Column(name = "Emails")
    private String emails;

    /**
     * Ngày chia sẻ
     */
    @Temporal(TemporalType.DATE)
    @Column(name = "ShareDate")
    private Date shareDate;

    // ===== GETTER & SETTER =====

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public String getEmails() {
        return emails;
    }

    public void setEmails(String emails) {
        this.emails = emails;
    }

    public Date getShareDate() {
        return shareDate;
    }

    public void setShareDate(Date shareDate) {
        this.shareDate = shareDate;
    }
}
