package poly.entity;

import jakarta.persistence.*;
import java.util.List;

/**
 * Entity Video
 * ↔ Map với bảng Videos trong DB
 */
@Entity
@Table(name = "Videos")
public class Video {

    /**
     * Khóa chính
     * VARCHAR(50)
     */
    @Id
    @Column(name = "Id", length = 50)
    private String id;

    /**
     * Tiêu đề video
     * NVARCHAR(200)
     */
    @Column(name = "Title")
    private String title;

    /**
     * Tên file poster / thumbnail
     */
    @Column(name = "Poster")
    private String poster;

    /**
     * Số lượt xem
     */
    @Column(name = "Views")
    private Integer views;

    /**
     * Mô tả nội dung video
     */
    @Column(name = "Description")
    private String description;

    /**
     * Trạng thái video
     * true  → đang hiển thị
     * false → bị ẩn
     */
    @Column(name = "Active")
    private Boolean active;

    /**
     * 1 video có thể được nhiều user like
     */
    @OneToMany(mappedBy = "video")
    private List<Favorite> favorites;

    /**
     * 1 video có thể được share nhiều lần
     */
    @OneToMany(mappedBy = "video")
    private List<Share> shares;

    // ===== GETTER & SETTER =====

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public Integer getViews() {
        return views;
    }

    public void setViews(Integer views) {
        this.views = views;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public List<Favorite> getFavorites() {
        return favorites;
    }

    public void setFavorites(List<Favorite> favorites) {
        this.favorites = favorites;
    }

    public List<Share> getShares() {
        return shares;
    }

    public void setShares(List<Share> shares) {
        this.shares = shares;
    }
}
