package poly.entity;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entity Favorite
 * → Bảng trung gian User – Video
 * → Dùng cho chức năng LIKE
 */
@Entity
@Table(
    name = "Favorites",
    uniqueConstraints = {
        /**
         * 1 user chỉ được like 1 video 1 lần
         */
        @UniqueConstraint(columnNames = {"UserId", "VideoId"})
    }
)
public class Favorite {

    /**
     * Khóa chính tự tăng
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long id;

    /**
     * Nhiều Favorite thuộc về 1 User
     */
    @ManyToOne
    @JoinColumn(name = "UserId", nullable = false)
    private User user;

    /**
     * Nhiều Favorite thuộc về 1 Video
     */
    @ManyToOne
    @JoinColumn(name = "VideoId", nullable = false)
    private Video video;

    /**
     * Ngày like
     */
    @Temporal(TemporalType.DATE)
    @Column(name = "LikeDate")
    private Date likeDate;

    // ===== GETTER & SETTER =====

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public Date getLikeDate() {
        return likeDate;
    }

    public void setLikeDate(Date likeDate) {
        this.likeDate = likeDate;
    }
}
